// Fill out your copyright notice in the Description page of Project Settings.

#include "MyProject.h"
#include "PlayerOne.h"
#include "FPSProjectile.h"


// Sets default values
APlayerOne::APlayerOne()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
    
    

}

// Called when the game starts or when spawned
void APlayerOne::BeginPlay()
{
	Super::BeginPlay();
    
    AutoPossessPlayer = EAutoReceiveInput::Player0;
    Ammo = 5;
    MaxAmmo = 10;
	
}

// Called every frame
void APlayerOne::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

    {
        if (!CurrentVelocity.IsZero())
        {
            FVector NewLocation = GetActorLocation() + (CurrentVelocity * DeltaTime);
            SetActorLocation(NewLocation);
        }
    }
    
    
}

// Called to bind functionality to input
void APlayerOne::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);
    
    InputComponent->BindAxis("Move_X", this, &APlayerOne::Move_XAxis);
    InputComponent->BindAxis("Move_Y", this, &APlayerOne::Move_YAxis);
    
    InputComponent->BindAction("Fire", IE_Pressed, this, &APlayerOne::Fire);

    InputComponent->BindAction("StartDash", IE_Pressed, this, &APlayerOne::StartDash);
}

void APlayerOne::Move_XAxis(float AxisValue)
{
    // Move at 100 units per second forward or backward
    CurrentVelocity.X = FMath::Clamp(AxisValue, -1.0f, 1.0f) * Speed;
}

void APlayerOne::Move_YAxis(float AxisValue)
{
    // Move at 100 units per second right or left
    CurrentVelocity.Y = FMath::Clamp(AxisValue, -1.0f, 1.0f) * Speed;
}

void APlayerOne::StartDash()
{
    
    return;
}


void APlayerOne::Fire()
{
    if (Ammo > 0)
    {
        
     
        if (ProjectileClass)
        {
            UWorld* World = GetWorld();
            if (World)
            {
                FActorSpawnParameters SpawnParams;
                SpawnParams.Owner = this;
                SpawnParams.Instigator = Instigator;
                // Spawn the projectile at the muzzle.
            
                FVector Location = GetActorLocation();
                FRotator Rotation = GetActorRotation();
            
                AFPSProjectile* Projectile = World->SpawnActor<AFPSProjectile>(ProjectileClass, Location, Rotation, SpawnParams);
                if (Projectile)
                {
                // Set the projectile's initial trajectory.
                FVector LaunchDirection = Rotation.Vector();
                Projectile->FireInDirection(LaunchDirection);
            }
        }
        Ammo--;
    }
    }
}


