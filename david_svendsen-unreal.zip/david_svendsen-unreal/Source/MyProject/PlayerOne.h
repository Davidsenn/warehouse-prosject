// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/Pawn.h"
#include "PlayerOne.generated.h"

UCLASS()
class MYPROJECT_API APlayerOne : public APawn
{
	GENERATED_BODY()

public:
	// Sets default values for this pawn's properties
	APlayerOne();

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	
	// Called every frame
	virtual void Tick( float DeltaSeconds ) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* InputComponent) override;

    void Move_XAxis(float AxisValue);
    void Move_YAxis(float AxisValue);
    void StartDash();
    
    UFUNCTION()
    void Fire();
    
    FVector CurrentVelocity;
    
    float Speed = 550.f;
    
    UPROPERTY(BlueprintReadWrite, Category = Ammo)
    int Ammo = 0;
    UPROPERTY(BlueprintReadOnly, Category = Ammo)
    int MaxAmmo = 0;
    
    // Projectile class to spawn.
    UPROPERTY(EditDefaultsOnly, Category = Projectile)
    TSubclassOf<class AFPSProjectile> ProjectileClass;
    

	
};
