// Fill out your copyright notice in the Description page of Project Settings.

#include "MyProject.h"
#include "PlayerTwo.h"


// Sets default values
APlayerTwo::APlayerTwo()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void APlayerTwo::BeginPlay()
{
	Super::BeginPlay();
    
    AutoPossessPlayer = EAutoReceiveInput::Player1;
	
}

// Called every frame
void APlayerTwo::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );
    
    {
        if (!CurrentVelocity.IsZero())
        {
            FVector NewLocation = GetActorLocation() + (CurrentVelocity * DeltaTime);
            SetActorLocation(NewLocation);
        }
    }


}

// Called to bind functionality to input
void APlayerTwo::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);
    
    InputComponent->BindAxis("MoveX", this, &APlayerTwo::Move_XAxis);
    InputComponent->BindAxis("MoveY", this, &APlayerTwo::Move_YAxis);


}

void APlayerTwo::Move_XAxis(float AxisValue)
{
    // Move at 100 units per second forward or backward
    CurrentVelocity.X = FMath::Clamp(AxisValue, -1.0f, 1.0f) * 400.0f;
}

void APlayerTwo::Move_YAxis(float AxisValue)
{
    // Move at 100 units per second right or left
    CurrentVelocity.Y = FMath::Clamp(AxisValue, -1.0f, 1.0f) * 400.0f;
}

void APlayerTwo::StartDash()
{
    
    return;
}

void APlayerTwo::Shoot()
{
    return;
}
